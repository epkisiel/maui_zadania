﻿int a = 25, b = 4;

Console.WriteLine("Liczba a = " + a);
Console.WriteLine("Liczba b = "+b);
Console.WriteLine("Suma: " + (a + b));
Console.WriteLine("Różnica: " + (a - b));
Console.WriteLine("Iloczyn: " + (a * b));
Console.WriteLine("Iloraz: " + (a / b));
Console.WriteLine("Reszta z dzielenia: " + (a % b));