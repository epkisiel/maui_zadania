﻿Console.WriteLine("Podaj imię: ");
string imie = Console.ReadLine();

Console.WriteLine("Podaj nazwisko: ");
string nazwisko = Console.ReadLine();

Console.WriteLine("Podaj wiek: ");
string podanyWiek = Console.ReadLine();

Console.WriteLine("Podaj email: ");
string email= Console.ReadLine();

Console.WriteLine("Podaj numer telefonu: ");
string telefon = Console.ReadLine();

bool czyPoprawnyWiek=false,czyPoprawnyTelefon=false,czyPoprawnyEmail=false;

if(int.TryParse(podanyWiek,out int wiek))
{
    if (wiek > 18 && wiek < 100)
    {
        Console.WriteLine("Wiek OK");
        czyPoprawnyWiek = true;
    }
    else
    {
        string blad = "Podany wiek nie jest w przedziale 18-100.";
        Console.WriteLine("Wiek Błąd: " + blad);
    }
}
else
{
    string blad = "Podany wiek jes nieprawidłowy.";
    Console.WriteLine("Wiek Błąd: " + blad);
}

if (email.Contains('@'))
{
    Console.WriteLine("Email OK");
    czyPoprawnyEmail = true;
}
else
{
    string blad = "Podany email jest nieprawidłowy.";
    Console.WriteLine("Email Błąd: " + blad);
}

if (telefon.Length == 9)
{
    Console.WriteLine("Telefon OK");
    czyPoprawnyTelefon = true;
}
else
{
    string blad = "Podany numer telefonu jest nieprawidłowy.";
    Console.WriteLine("Telefon Błąd: "+blad);
}

if (czyPoprawnyTelefon&&czyPoprawnyWiek&&czyPoprawnyEmail)
{
    Console.WriteLine("Wszystkie dane są poprawne. Rejestracja zakończona sukcesem!");
}
else
{
    Console.WriteLine("Formularz zawiera błędy. Popraw dane i spróbuj ponownie.");
}