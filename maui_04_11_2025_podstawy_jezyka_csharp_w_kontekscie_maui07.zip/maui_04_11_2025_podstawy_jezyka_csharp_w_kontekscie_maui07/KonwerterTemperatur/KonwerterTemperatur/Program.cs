﻿double temperaturaCelsjusz = 25;
double temperaturaFahrenheit = temperaturaCelsjusz * 9 / 5 + 32;
temperaturaCelsjusz = (temperaturaFahrenheit - 32) * 5 / 9;

Console.WriteLine("Celsjusz: " + temperaturaCelsjusz);
Console.WriteLine("Fahrenheit: " + temperaturaFahrenheit);
if (temperaturaCelsjusz < 0)
{
    Console.WriteLine("Uwaga: temperatura poniżej zera!");
}